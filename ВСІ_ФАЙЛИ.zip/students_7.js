// Практична 7 — Варіант 1
// Система управління студентами + Алгоритми сортування

// ===== ДАНІ =====
var db = [
  {id:1, name:"Іван Петренко",    age:20, gpa:91.5, faculty:"IT"},
  {id:2, name:"Марія Коваль",     age:22, gpa:78.0, faculty:"Math"},
  {id:3, name:"Олег Мельник",     age:21, gpa:65.3, faculty:"IT"},
  {id:4, name:"Анна Сидоренко",   age:19, gpa:95.0, faculty:"Physics"},
  {id:5, name:"Дмитро Іванов",    age:23, gpa:55.8, faculty:"Math"},
  {id:6, name:"Софія Бойко",      age:20, gpa:88.4, faculty:"IT"},
  {id:7, name:"Максим Ткач",      age:21, gpa:72.1, faculty:"Physics"},
  {id:8, name:"Юлія Шевченко",    age:22, gpa:83.7, faculty:"IT"},
  {id:9, name:"Артем Гриценко",   age:20, gpa:60.0, faculty:"Math"},
  {id:10,name:"Катерина Лисенко", age:19, gpa:98.2, faculty:"Physics"}
];
var nextId = 11;

// ===== НАВІГАЦІЯ =====
function showPage(id, btn) {
  document.querySelectorAll('.page').forEach(function(p){ p.classList.remove('active'); });
  document.querySelectorAll('.nav-btn').forEach(function(b){ b.classList.remove('active'); });
  document.getElementById('page-'+id).classList.add('active');
  btn.classList.add('active');
  if(id==='stats') renderStats();
  if(id==='methods') renderMethods();
  if(id==='destruct') renderDestruct();
  if(id==='filter') doFilter();
}

// ===== СПИСОК =====
function renderList() {
  var field = document.getElementById('sf').value;
  var dir   = document.getElementById('sd').value;
  var arr = db.slice().sort(function(a,b){
    if(field==='name') return a.name.localeCompare(b.name,'uk');
    return a[field]-b[field];
  });
  if(dir==='desc') arr.reverse();
  var html = '';
  for(var i=0;i<arr.length;i++){
    var s=arr[i];
    html+='<tr>'+
      '<td style="color:#64748b">#'+s.id+'</td>'+
      '<td>'+s.name+'</td>'+
      '<td>'+s.age+'</td>'+
      '<td>'+s.gpa+'</td>'+
      '<td><span class="tag tag-'+s.faculty+'">'+s.faculty+'</span></td>'+
      '<td><button class="btn-del" onclick="delStudent('+s.id+')">✕</button></td>'+
    '</tr>';
  }
  document.getElementById('list-tbody').innerHTML = html;
}

function delStudent(id) {
  db = db.filter(function(s){ return s.id!==id; });
  renderList();
}

// ===== ДОДАТИ =====
function doAdd() {
  var name = document.getElementById('a-name').value.trim();
  var age  = parseInt(document.getElementById('a-age').value);
  var gpa  = parseFloat(document.getElementById('a-gpa').value);
  var fac  = document.getElementById('a-fac').value;
  var msg  = document.getElementById('add-msg');

  if(!name){ msg.innerHTML='<div class="alert alert-err">✗ Введіть ім\'я</div>'; return; }
  if(isNaN(age)||age<16||age>100){ msg.innerHTML='<div class="alert alert-err">✗ Вік: від 16 до 100</div>'; return; }
  if(isNaN(gpa)||gpa<0||gpa>100){ msg.innerHTML='<div class="alert alert-err">✗ GPA: від 0 до 100</div>'; return; }

  db.push({id:nextId++, name:name, age:age, gpa:gpa, faculty:fac});
  renderList();
  msg.innerHTML='<div class="alert alert-ok">✓ Студента "'+name+'" додано!</div>';
  document.getElementById('a-name').value='';
  document.getElementById('a-age').value='';
  document.getElementById('a-gpa').value='';
  setTimeout(function(){ msg.innerHTML=''; }, 3000);
}

// ===== ФІЛЬТР =====
function doFilter() {
  var name = document.getElementById('f-name').value.toLowerCase();
  var fac  = document.getElementById('f-fac').value;
  var min  = parseFloat(document.getElementById('f-min').value)||0;
  var res  = db.filter(function(s){
    if(fac && s.faculty!==fac) return false;
    if(s.gpa<min) return false;
    if(name && s.name.toLowerCase().indexOf(name)===-1) return false;
    return true;
  });
  var html='';
  for(var i=0;i<res.length;i++){
    var s=res[i];
    html+='<tr><td>'+s.name+'</td><td>'+s.age+'</td><td>'+s.gpa+'</td>'+
      '<td><span class="tag tag-'+s.faculty+'">'+s.faculty+'</span></td></tr>';
  }
  document.getElementById('filter-tbody').innerHTML=html;
  document.getElementById('filter-count').textContent='Знайдено: '+res.length+' студентів';
}

function clearFilter() {
  document.getElementById('f-name').value='';
  document.getElementById('f-fac').value='';
  document.getElementById('f-min').value='';
  doFilter();
}

// ===== СТАТИСТИКА =====
function renderStats() {
  if(!db.length) return;
  var avg = 0;
  for(var i=0;i<db.length;i++) avg+=db[i].gpa;
  avg = (avg/db.length).toFixed(2);

  var sorted = db.slice().sort(function(a,b){return b.gpa-a.gpa;});
  var best = sorted[0];
  var top3 = sorted.slice(0,3);

  var dist = {};
  for(var i=0;i<db.length;i++){
    var f=db[i].faculty;
    dist[f]=(dist[f]||0)+1;
  }

  document.getElementById('stats-cards').innerHTML=
    '<div class="stat"><div class="stat-val">'+db.length+'</div><div class="stat-lbl">Студентів</div></div>'+
    '<div class="stat"><div class="stat-val">'+avg+'</div><div class="stat-lbl">Середній GPA</div></div>'+
    '<div class="stat"><div class="stat-val">'+best.gpa+'</div><div class="stat-lbl">Максимум GPA</div></div>'+
    '<div class="stat"><div class="stat-val">'+Object.keys(dist).length+'</div><div class="stat-lbl">Факультетів</div></div>';

  var medals=['🥇','🥈','🥉'];
  var t3='';
  for(var i=0;i<top3.length;i++){
    t3+='<div class="top3-item"><div class="top3-medal">'+medals[i]+'</div>'+
      '<div class="top3-name">'+top3[i].name+'</div>'+
      '<div class="top3-gpa">'+top3[i].gpa+'</div></div>';
  }
  document.getElementById('top3').innerHTML=t3;

  var bars='';
  var keys=Object.keys(dist);
  for(var i=0;i<keys.length;i++){
    var f=keys[i], c=dist[f];
    bars+='<div class="bar-row">'+
      '<div class="bar-label"><span>'+f+'</span><span>'+c+' студ.</span></div>'+
      '<div class="bar-track"><div class="bar-fill" style="width:'+(c/db.length*100).toFixed(0)+'%"></div></div>'+
    '</div>';
  }
  document.getElementById('fac-bars').innerHTML=bars;
}

// ===== BUBBLE SORT =====
function bubbleSort(arr) {
  var a=arr.slice(), comparisons=0, swaps=0, n=a.length;
  for(var i=0;i<n-1;i++){
    var swapped=false;
    for(var j=0;j<n-i-1;j++){
      comparisons++;
      if(a[j]>a[j+1]){ var t=a[j];a[j]=a[j+1];a[j+1]=t; swaps++; swapped=true; }
    }
    if(!swapped) break;
  }
  return {sorted:a, comparisons:comparisons, swaps:swaps};
}

// ===== QUICK SORT =====
function quickSort(arr) {
  var comparisons=0, swaps=0;
  function partition(a,lo,hi){
    var pivot=a[hi],i=lo-1;
    for(var j=lo;j<hi;j++){
      comparisons++;
      if(a[j]<=pivot){ i++; var t=a[i];a[i]=a[j];a[j]=t; swaps++; }
    }
    var t=a[i+1];a[i+1]=a[hi];a[hi]=t; swaps++;
    return i+1;
  }
  function sort(a,lo,hi){ if(lo<hi){ var p=partition(a,lo,hi); sort(a,lo,p-1); sort(a,p+1,hi); } }
  var a=arr.slice(); sort(a,0,a.length-1);
  return {sorted:a, comparisons:comparisons, swaps:swaps};
}

function randArr(n){ var a=[]; for(var i=0;i<n;i++) a.push(Math.floor(Math.random()*10000)); return a; }

// ===== BENCHMARK =====
function doBenchmark() {
  var sizes=[100,1000,5000];
  var html='<table style="width:100%;border-collapse:collapse">'+
    '<thead><tr><th style="text-align:left;padding:8px;color:#64748b">Розмір</th>'+
    '<th style="text-align:left;padding:8px;color:#ef4444">Bubble час</th>'+
    '<th style="text-align:left;padding:8px;color:#ef4444">Bubble порівнянь</th>'+
    '<th style="text-align:left;padding:8px;color:#22c55e">Quick час</th>'+
    '<th style="text-align:left;padding:8px;color:#22c55e">Quick порівнянь</th>'+
    '</tr></thead><tbody>';
  for(var i=0;i<sizes.length;i++){
    var n=sizes[i], arr=randArr(n);
    var t1=performance.now(); var br=bubbleSort(arr); var t2=performance.now();
    var t3=performance.now(); var qr=quickSort(arr); var t4=performance.now();
    html+='<tr>'+
      '<td style="padding:8px;color:#4f8ef7">'+n.toLocaleString()+'</td>'+
      '<td style="padding:8px;color:#ef4444">'+(t2-t1).toFixed(2)+' мс</td>'+
      '<td style="padding:8px;color:#64748b">'+br.comparisons.toLocaleString()+'</td>'+
      '<td style="padding:8px;color:#22c55e">'+(t4-t3).toFixed(2)+' мс</td>'+
      '<td style="padding:8px;color:#64748b">'+qr.comparisons.toLocaleString()+'</td>'+
    '</tr>';
  }
  html+='</tbody></table>';
  document.getElementById('bench-out').innerHTML=html;
}

// ===== ВІЗУАЛІЗАЦІЯ =====
function doViz() {
  var raw=document.getElementById('viz-in').value;
  var arr=raw.split(',').map(function(x){return parseInt(x.trim());}).filter(function(x){return !isNaN(x);}).slice(0,16);
  if(!arr.length) return;

  // Зібрати всі кроки
  var steps=[], a=arr.slice(), n=a.length;
  steps.push({arr:a.slice(),hi:[]});
  for(var i=0;i<n-1;i++){
    for(var j=0;j<n-i-1;j++){
      if(a[j]>a[j+1]){ var t=a[j];a[j]=a[j+1];a[j+1]=t; steps.push({arr:a.slice(),hi:[j,j+1]}); }
    }
  }

  var step=0;
  function render(){
    var s=steps[step], mx=Math.max.apply(null,s.arr);
    var bars='';
    for(var k=0;k<s.arr.length;k++){
      var h=Math.max(8,(s.arr[k]/mx*90)).toFixed(0);
      var color=s.hi.indexOf(k)>=0?'#f59e0b':'#4f8ef7';
      bars+='<div class="viz-bar" style="height:'+h+'px;background:'+color+'"><span>'+s.arr[k]+'</span></div>';
    }
    document.getElementById('viz-out').innerHTML=
      '<div class="viz-bars">'+bars+'</div>'+
      '<div style="display:flex;gap:8px;align-items:center;margin-top:20px">'+
      '<button class="btn btn-gray" onclick="vizStep(-1)">◀ Назад</button>'+
      '<span style="color:#64748b;font-size:12px">Крок '+(step+1)+' / '+steps.length+'</span>'+
      '<button class="btn btn-gray" onclick="vizStep(1)">Вперед ▶</button>'+
      '</div>';
  }
  window._vizSteps=steps;
  window._vizStep=0;
  step=0; render();
  window._vizRender=render;
}

function vizStep(d){
  if(!window._vizSteps) return;
  window._vizStep=Math.max(0,Math.min(window._vizSteps.length-1,window._vizStep+d));
  var step=window._vizStep;
  var steps=window._vizSteps;
  var s=steps[step], mx=Math.max.apply(null,s.arr);
  var bars='';
  for(var k=0;k<s.arr.length;k++){
    var h=Math.max(8,(s.arr[k]/mx*90)).toFixed(0);
    var color=s.hi.indexOf(k)>=0?'#f59e0b':'#4f8ef7';
    bars+='<div class="viz-bar" style="height:'+h+'px;background:'+color+'"><span>'+s.arr[k]+'</span></div>';
  }
  document.getElementById('viz-out').innerHTML=
    '<div class="viz-bars">'+bars+'</div>'+
    '<div style="display:flex;gap:8px;align-items:center;margin-top:20px">'+
    '<button class="btn btn-gray" onclick="vizStep(-1)">◀ Назад</button>'+
    '<span style="color:#64748b;font-size:12px">Крок '+(step+1)+' / '+steps.length+'</span>'+
    '<button class="btn btn-gray" onclick="vizStep(1)">Вперед ▶</button>'+
    '</div>';
}

// ===== МЕТОДИ МАСИВІВ =====
function renderMethods() {
  var demo = db.slice(0,5);
  var orig = demo.slice(); // slice — копія

  // push
  var afterPush = demo.slice(); afterPush.push({id:99,name:"Push Студент",age:20,gpa:70,faculty:"IT"});
  // unshift
  var afterUnshift = demo.slice(); afterUnshift.unshift({id:98,name:"Unshift Студент",age:21,gpa:80,faculty:"Math"});
  // pop
  var afterPop = demo.slice(); var popped = afterPop.pop();
  // shift
  var afterShift = demo.slice(); var shifted = afterShift.shift();
  // splice
  var afterSplice = demo.slice(); var removed = afterSplice.splice(1,1,{id:97,name:"Splice Заміна",age:22,gpa:85,faculty:"IT"});

  var html=
    '<div class="method-step"><code>slice(0, 5)</code><p>Повертає копію перших 5 елементів без зміни оригіналу. Отримано: '+orig.length+' елементів</p></div>'+
    '<div class="method-step"><code>push(student)</code><p>Додає елемент в кінець масиву. Після push: '+afterPush.length+' елементів. Останній: "'+afterPush[afterPush.length-1].name+'"</p></div>'+
    '<div class="method-step"><code>unshift(student)</code><p>Додає елемент на початок масиву. Перший: "'+afterUnshift[0].name+'"</p></div>'+
    '<div class="method-step"><code>pop()</code><p>Видаляє та повертає останній елемент. Видалено: "'+popped.name+'"</p></div>'+
    '<div class="method-step"><code>shift()</code><p>Видаляє та повертає перший елемент. Видалено: "'+shifted.name+'"</p></div>'+
    '<div class="method-step"><code>splice(1, 1, newStudent)</code><p>Замінює 1 елемент на позиції 1. Видалено: "'+removed[0].name+'". Додано: "'+afterSplice[1].name+'"</p></div>';
  document.getElementById('methods-out').innerHTML=html;
}

// ===== ДЕСТРУКТУРИЗАЦІЯ =====
function renderDestruct() {
  var arr = db.slice(0,5);
  var first=arr[0], second=arr[1], rest=arr.slice(2);

  // groupByFaculty — 2D масив
  var map={};
  for(var i=0;i<db.length;i++){ var f=db[i].faculty; if(!map[f])map[f]=[]; map[f].push(db[i].name); }
  var matrix=Object.keys(map).map(function(f){return [f, map[f]];});

  // for...of names
  var names=[]; for(var i=0;i<arr.length;i++) names.push(arr[i].name);
  // entries
  var indexed=[]; for(var i=0;i<arr.length;i++) indexed.push(i+': '+arr[i].name);

  var html=
    '<div class="card"><h3>Деструктуризація масиву</h3>'+
    '<pre>const [first, second, ...rest] = students;\n'+
    '// first  → '+first.name+' (GPA: '+first.gpa+')\n'+
    '// second → '+second.name+' (GPA: '+second.gpa+')\n'+
    '// ...rest → '+rest.length+' студентів</pre></div>'+

    '<div class="card"><h3>Spread оператор</h3>'+
    '<pre>const merged = [...groupA, ...groupB];\n'+
    '// Результат: '+db.length+' студентів у злитому масиві</pre></div>'+

    '<div class="card"><h3>Rest оператор у функції</h3>'+
    '<pre>const createGroup = (...students) => students;\n'+
    '// Приймає будь-яку кількість аргументів</pre></div>'+

    '<div class="card"><h3>Багатовимірний масив — groupByFaculty()</h3>'+
    '<pre>'+JSON.stringify(matrix.map(function(r){return [r[0], r[1].length+' студ.'];}),null,2)+'</pre></div>'+

    '<div class="card"><h3>Ітерація — for...of, forEach, entries()</h3>'+
    '<pre>// for...of → '+names.slice(0,3).join(', ')+'...\n'+
    '// entries() → '+indexed.slice(0,3).join(', ')+'...</pre></div>';

  document.getElementById('destruct-out').innerHTML=html;
}

// ===== ІНІЦІАЛІЗАЦІЯ =====
renderList();
doFilter();
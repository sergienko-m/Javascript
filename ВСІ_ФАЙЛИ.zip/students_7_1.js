// Практична 7.1 — Варіант 1
// Операції з масивами: map, filter, reduce, find, sort

var db = [
  {id:1, name:"Іван Петренко",    age:20, grade:85.5, faculty:"IT"},
  {id:2, name:"Марія Коваль",     age:22, grade:78.0, faculty:"Math"},
  {id:3, name:"Олег Мельник",     age:21, grade:65.3, faculty:"IT"},
  {id:4, name:"Анна Сидоренко",   age:19, grade:95.0, faculty:"Physics"},
  {id:5, name:"Дмитро Іванов",    age:23, grade:55.8, faculty:"Math"},
  {id:6, name:"Софія Бойко",      age:20, grade:88.4, faculty:"IT"},
  {id:7, name:"Максим Ткач",      age:21, grade:72.1, faculty:"Physics"},
  {id:8, name:"Юлія Шевченко",    age:22, grade:83.7, faculty:"IT"},
  {id:9, name:"Артем Гриценко",   age:20, grade:60.0, faculty:"Math"},
  {id:10,name:"Катерина Лисенко", age:19, grade:98.2, faculty:"Physics"},
  {id:11,name:"Роман Ковальчук",  age:24, grade:91.0, faculty:"IT"},
  {id:12,name:"Оксана Поліщук",   age:20, grade:44.5, faculty:"Math"}
];
var nid=13;

function lg(g){ return g>=90?'A':g>=80?'B':g>=70?'C':g>=60?'D':'F'; }

function switchTab(id,el){
  document.querySelectorAll('.panel').forEach(function(p){p.classList.remove('active');});
  document.querySelectorAll('.tab').forEach(function(t){t.classList.remove('active');});
  document.getElementById('panel-'+id).classList.add('active');
  el.classList.add('active');
  if(id==='stats') renderStats();
  if(id==='transform') renderTransform();
  if(id==='filter') doFilter();
  updateStatsRow();
}

function updateStatsRow(){
  if(!db.length) return;
  var avg=0; for(var i=0;i<db.length;i++) avg+=db[i].grade; avg=(avg/db.length).toFixed(2);
  var sorted=db.slice().sort(function(a,b){return b.grade-a.grade;});
  var aboveAvg=db.filter(function(s){return s.grade>avg;}).length;
  document.getElementById('stats-row').innerHTML=
    '<div class="stat"><div class="stat-val">'+db.length+'</div><div class="stat-lbl">Студентів</div></div>'+
    '<div class="stat"><div class="stat-val">'+avg+'</div><div class="stat-lbl">Середня оцінка</div></div>'+
    '<div class="stat"><div class="stat-val">'+sorted[0].grade+'</div><div class="stat-lbl">Максимум</div></div>'+
    '<div class="stat"><div class="stat-val">'+sorted[sorted.length-1].grade+'</div><div class="stat-lbl">Мінімум</div></div>'+
    '<div class="stat"><div class="stat-val">'+aboveAvg+'</div><div class="stat-lbl">Вище середнього</div></div>';
}

function renderList(){
  var by=document.getElementById('sb').value;
  var dir=document.getElementById('sd').value;
  var arr=db.slice().sort(function(a,b){
    if(by==='name') return a.name.localeCompare(b.name,'uk');
    return a[by]-b[by];
  });
  if(dir==='desc') arr.reverse();
  var html='';
  for(var i=0;i<arr.length;i++){
    var s=arr[i], l=lg(s.grade);
    html+='<tr><td>'+s.name+'</td><td>'+s.age+'</td><td>'+s.grade+'</td>'+
      '<td><span class="grade g'+l+'">'+l+'</span></td>'+
      '<td><span class="tag tag-'+s.faculty+'">'+s.faculty+'</span></td>'+
      '<td><button class="btn-del" onclick="del('+s.id+')">✕</button></td></tr>';
  }
  document.getElementById('list-body').innerHTML=html;
  updateStatsRow();
}

function del(id){ db=db.filter(function(s){return s.id!==id;}); renderList(); }

function doAdd(){
  var name=document.getElementById('fn').value.trim();
  var age=parseInt(document.getElementById('fa').value);
  var grade=parseFloat(document.getElementById('fg').value);
  var fac=document.getElementById('ff').value;
  var msg=document.getElementById('add-msg');
  if(!name){msg.innerHTML='<div class="alert alert-err">✗ Введіть ім\'я</div>';return;}
  if(isNaN(age)||age<16||age>100){msg.innerHTML='<div class="alert alert-err">✗ Вік: від 16 до 100</div>';return;}
  if(isNaN(grade)||grade<0||grade>100){msg.innerHTML='<div class="alert alert-err">✗ Оцінка: від 0 до 100</div>';return;}
  db.push({id:nid++,name:name,age:age,grade:grade,faculty:fac});
  renderList();
  msg.innerHTML='<div class="alert alert-ok">✓ "'+name+'" додано!</div>';
  document.getElementById('fn').value='';
  document.getElementById('fa').value='';
  document.getElementById('fg').value='';
  setTimeout(function(){msg.innerHTML='';},3000);
}

function doFilter(){
  var name=document.getElementById('ff-n').value.toLowerCase();
  var fac=document.getElementById('ff-f').value;
  var min=parseFloat(document.getElementById('ff-m').value)||0;
  var res=db.filter(function(s){
    if(fac&&s.faculty!==fac) return false;
    if(s.grade<min) return false;
    if(name&&s.name.toLowerCase().indexOf(name)===-1) return false;
    return true;
  });
  var html='';
  for(var i=0;i<res.length;i++){
    var s=res[i];
    html+='<tr><td>'+s.name+'</td><td>'+s.age+'</td><td>'+s.grade+'</td>'+
      '<td><span class="tag tag-'+s.faculty+'">'+s.faculty+'</span></td></tr>';
  }
  document.getElementById('filter-body').innerHTML=html;
  document.getElementById('finfo').textContent='Знайдено: '+res.length+' з '+db.length+' студентів';
}

function clearF(){
  document.getElementById('ff-n').value='';
  document.getElementById('ff-f').value='';
  document.getElementById('ff-m').value='';
  doFilter();
}

function renderStats(){
  var sorted=db.slice().sort(function(a,b){return b.grade-a.grade;});
  var medals=['🥇','🥈','🥉'],ranks=['r1','r2','r3'];
  var t3='';
  for(var i=0;i<3&&i<sorted.length;i++){
    t3+='<div class="top3-card '+ranks[i]+'">'+
      '<div class="top3-medal">'+medals[i]+'</div>'+
      '<div class="top3-name">'+sorted[i].name+'</div>'+
      '<div class="top3-grade">'+sorted[i].grade+'</div>'+
      '<div style="font-size:11px;color:#8a7e72">'+sorted[i].faculty+'</div></div>';
  }
  document.getElementById('top3').innerHTML=t3;

  // reduce по факультетах
  var byF={};
  for(var i=0;i<db.length;i++){
    var f=db[i].faculty;
    if(!byF[f]) byF[f]={count:0,total:0};
    byF[f].count++; byF[f].total+=db[i].grade;
  }
  var bars='';
  var keys=Object.keys(byF);
  for(var i=0;i<keys.length;i++){
    var f=keys[i],d=byF[f];
    bars+='<div class="bar-row">'+
      '<div class="bar-label"><span>'+f+'</span><span>'+d.count+' студ. · Ø '+(d.total/d.count).toFixed(1)+'</span></div>'+
      '<div class="bar-track"><div class="bar-fill" style="width:'+(d.count/db.length*100).toFixed(0)+'%"></div></div></div>';
  }
  document.getElementById('fac-dist').innerHTML=bars;

  var avg=0; for(var i=0;i<db.length;i++) avg+=db[i].grade; avg=(avg/db.length).toFixed(2);
  var best=sorted[0],worst=sorted[sorted.length-1];
  var aboveAvg=db.filter(function(s){return s.grade>avg;}).length;
  document.getElementById('stat-detail').innerHTML=
    '<div style="background:#f8f5f0;border-radius:10px;padding:14px"><div style="font-size:11px;color:#8a7e72;font-weight:700;margin-bottom:4px">НАЙКРАЩИЙ</div><div style="font-size:17px;font-weight:700">'+best.name+'</div><div style="color:#8a7e72;font-size:12px">Оцінка: '+best.grade+'</div></div>'+
    '<div style="background:#f8f5f0;border-radius:10px;padding:14px"><div style="font-size:11px;color:#8a7e72;font-weight:700;margin-bottom:4px">НАЙГІРШИЙ</div><div style="font-size:17px;font-weight:700">'+worst.name+'</div><div style="color:#8a7e72;font-size:12px">Оцінка: '+worst.grade+'</div></div>'+
    '<div style="background:#f8f5f0;border-radius:10px;padding:14px"><div style="font-size:11px;color:#8a7e72;font-weight:700;margin-bottom:4px">ВИЩЕ СЕРЕДНЬОГО</div><div style="font-size:17px;font-weight:700">'+aboveAvg+' студ.</div><div style="color:#8a7e72;font-size:12px">Ø = '+avg+'</div></div>';
}

function renderTransform(){
  // map — літерні оцінки
  var html='';
  for(var i=0;i<db.length;i++){
    var s=db[i],l=lg(s.grade);
    html+='<tr><td>'+s.name+'</td><td>'+s.grade+'</td>'+
      '<td><span class="grade g'+l+'">'+l+'</span></td>'+
      '<td><span class="tag tag-'+s.faculty+'">'+s.faculty+'</span></td></tr>';
  }
  document.getElementById('map-body').innerHTML=html;

  // reduce по факультетах
  var byF={};
  for(var i=0;i<db.length;i++){
    var f=db[i].faculty;
    if(!byF[f]) byF[f]={count:0,total:0};
    byF[f].count++; byF[f].total+=db[i].grade;
  }
  html='';
  var keys=Object.keys(byF);
  for(var i=0;i<keys.length;i++){
    var f=keys[i],d=byF[f];
    html+='<tr><td><span class="tag tag-'+f+'">'+f+'</span></td>'+
      '<td>'+d.count+'</td><td>'+(d.total/d.count).toFixed(2)+'</td></tr>';
  }
  document.getElementById('reduce-body').innerHTML=html;

  // normalize
  html='';
  for(var i=0;i<db.length;i++){
    var s=db[i];
    html+='<tr><td>'+s.name+'</td><td>'+s.grade+'</td><td><strong>'+(s.grade/20).toFixed(1)+'</strong></td></tr>';
  }
  document.getElementById('norm-body').innerHTML=html;
}

renderList();
doFilter();
updateStatsRow();
// Практична 7.2 — Варіант 1
// Алгоритми сортування: Bubble, Selection, Insertion, Merge, Quick

// ===== АЛГОРИТМИ =====

function bubbleSort(arr){
  var a=arr.slice(),cmp=0,swp=0,n=a.length;
  for(var i=0;i<n-1;i++){
    var moved=false;
    for(var j=0;j<n-i-1;j++){
      cmp++;
      if(a[j]>a[j+1]){var t=a[j];a[j]=a[j+1];a[j+1]=t;swp++;moved=true;}
    }
    if(!moved) break;
  }
  return {sorted:a,cmp:cmp,swp:swp};
}

function selectionSort(arr){
  var a=arr.slice(),cmp=0,swp=0,n=a.length;
  for(var i=0;i<n-1;i++){
    var mi=i;
    for(var j=i+1;j<n;j++){cmp++;if(a[j]<a[mi])mi=j;}
    if(mi!==i){var t=a[i];a[i]=a[mi];a[mi]=t;swp++;}
  }
  return {sorted:a,cmp:cmp,swp:swp};
}

function insertionSort(arr){
  var a=arr.slice(),cmp=0,swp=0,n=a.length;
  for(var i=1;i<n;i++){
    var key=a[i],j=i-1;
    while(j>=0&&a[j]>key){cmp++;a[j+1]=a[j];swp++;j--;}
    if(j>=0)cmp++;
    a[j+1]=key;
  }
  return {sorted:a,cmp:cmp,swp:swp};
}

function mergeSort(arr){
  var cmp=0,swp=0;
  function merge(l,r){
    var res=[],li=0,ri=0;
    while(li<l.length&&ri<r.length){cmp++;if(l[li]<=r[ri])res.push(l[li++]);else{res.push(r[ri++]);swp++;}}
    while(li<l.length)res.push(l[li++]);
    while(ri<r.length)res.push(r[ri++]);
    return res;
  }
  function sort(a){if(a.length<=1)return a;var m=Math.floor(a.length/2);return merge(sort(a.slice(0,m)),sort(a.slice(m)));}
  return {sorted:sort(arr.slice()),cmp:cmp,swp:swp};
}

function quickSort(arr){
  var cmp=0,swp=0;
  function part(a,lo,hi){var p=a[hi],i=lo-1;for(var j=lo;j<hi;j++){cmp++;if(a[j]<=p){i++;var t=a[i];a[i]=a[j];a[j]=t;swp++;}}var t=a[i+1];a[i+1]=a[hi];a[hi]=t;swp++;return i+1;}
  function sort(a,lo,hi){if(lo<hi){var p=part(a,lo,hi);sort(a,lo,p-1);sort(a,p+1,hi);}}
  var a=arr.slice();sort(a,0,a.length-1);
  return {sorted:a,cmp:cmp,swp:swp};
}

var ALGOS=[
  {name:"Bubble Sort",   color:"#64ffda", fn:bubbleSort},
  {name:"Selection Sort",color:"#bb9af7", fn:selectionSort},
  {name:"Insertion Sort",color:"#7aa2f7", fn:insertionSort},
  {name:"Merge Sort",    color:"#9ece6a", fn:mergeSort},
  {name:"Quick Sort",    color:"#e0af68", fn:quickSort}
];

var COMPLEXITY={
  "Bubble Sort":    {best:"O(n)",      avg:"O(n²)",      worst:"O(n²)",      space:"O(1)",      stable:true},
  "Selection Sort": {best:"O(n²)",     avg:"O(n²)",      worst:"O(n²)",      space:"O(1)",      stable:false},
  "Insertion Sort": {best:"O(n)",      avg:"O(n²)",      worst:"O(n²)",      space:"O(1)",      stable:true},
  "Merge Sort":     {best:"O(n log n)",avg:"O(n log n)", worst:"O(n log n)", space:"O(n)",      stable:true},
  "Quick Sort":     {best:"O(n log n)",avg:"O(n log n)", worst:"O(n²)",      space:"O(log n)",  stable:false}
};

function clsO(o){return o.indexOf('²')>=0?'c-n2':o.indexOf('log')>=0?'c-nlogn':'c-n';}

// НАВІГАЦІЯ
function goPage(id,el){
  document.querySelectorAll('.page').forEach(function(p){p.classList.remove('active');});
  document.querySelectorAll('.nb').forEach(function(b){b.classList.remove('active');});
  document.getElementById('page-'+id).classList.add('active');
  el.classList.add('active');
}

// BIG O GRID
(function(){
  var html='';
  for(var i=0;i<ALGOS.length;i++){
    var a=ALGOS[i],c=COMPLEXITY[a.name];
    html+='<div class="algo-card">'+
      '<div class="algo-name" style="color:'+a.color+'">'+a.name+'</div>'+
      '<div class="crow"><span class="clabel">Best</span><span class="'+clsO(c.best)+'">'+c.best+'</span></div>'+
      '<div class="crow"><span class="clabel">Average</span><span class="'+clsO(c.avg)+'">'+c.avg+'</span></div>'+
      '<div class="crow"><span class="clabel">Worst</span><span class="'+clsO(c.worst)+'">'+c.worst+'</span></div>'+
      '<div class="crow"><span class="clabel">Space</span><span class="c-n">'+c.space+'</span></div>'+
      '<div class="crow"><span class="clabel">Stable</span><span class="'+(c.stable?'c-yes':'c-no')+'">'+(c.stable?'✓ так':'✗ ні')+'</span></div>'+
    '</div>';
  }
  document.getElementById('algo-grid').innerHTML=html;
})();

// ГЕНЕРАТОРИ
function mkArr(n,type){
  var a=[];
  for(var i=0;i<n;i++){
    if(type==='random')a.push(Math.floor(Math.random()*10000));
    else if(type==='sorted')a.push(i);
    else if(type==='reversed')a.push(n-i);
    else a.push(42);
  }
  return a;
}

// BENCHMARK
function doBenchmark(){
  var type=document.getElementById('bench-type').value;
  var sizes=[100,1000,5000];
  var html='<div style="overflow-x:auto"><table><thead><tr>'+
    '<th>Розмір</th><th>Тип</th>';
  for(var i=0;i<ALGOS.length;i++) html+='<th style="color:'+ALGOS[i].color+'">'+ALGOS[i].name+'</th>';
  html+='</tr></thead><tbody>';

  for(var si=0;si<sizes.length;si++){
    var n=sizes[si], arr=mkArr(n,type);
    html+='<tr><td style="color:#7aa2f7;font-weight:700">'+n.toLocaleString()+'</td>'+
      '<td style="color:#495670">'+document.getElementById('bench-type').options[document.getElementById('bench-type').selectedIndex].text+'</td>';
    for(var ai=0;ai<ALGOS.length;ai++){
      if(ALGOS[ai].name==='Bubble Sort'&&n>=5000&&type==='reversed'){
        html+='<td style="color:#f7768e">~дуже повільно</td>';continue;
      }
      var t1=performance.now();
      var r=ALGOS[ai].fn(arr);
      var t2=performance.now();
      var ms=(t2-t1).toFixed(2);
      var cls=ms<1?'t-fast':ms<20?'t-mid':'t-slow';
      html+='<td><span class="'+cls+'">'+ms+' мс</span><br><span style="color:#495670;font-size:11px">'+r.cmp.toLocaleString()+' порівн.</span></td>';
    }
    html+='</tr>';
  }
  html+='</tbody></table></div>';
  document.getElementById('bench-out').innerHTML=html;
}

// ВІЗУАЛІЗАЦІЯ
var _vsteps=[], _vstep=0;

function bubbleSteps(arr){
  var a=arr.slice(),n=a.length,steps=[];
  steps.push({arr:a.slice(),hi:[],done:[]});
  var done=[];
  for(var i=0;i<n-1;i++){
    var moved=false;
    for(var j=0;j<n-i-1;j++){
      if(a[j]>a[j+1]){var t=a[j];a[j]=a[j+1];a[j+1]=t;moved=true;steps.push({arr:a.slice(),hi:[j,j+1],done:done.slice()});}
    }
    done.push(n-1-i);
    if(!moved)break;
  }
  return steps;
}
function selectionSteps(arr){
  var a=arr.slice(),n=a.length,steps=[],done=[];
  steps.push({arr:a.slice(),hi:[],done:[]});
  for(var i=0;i<n-1;i++){
    var mi=i;
    for(var j=i+1;j<n;j++){if(a[j]<a[mi])mi=j;steps.push({arr:a.slice(),hi:[i,j,mi],done:done.slice()});}
    if(mi!==i){var t=a[i];a[i]=a[mi];a[mi]=t;}
    done.push(i);
    steps.push({arr:a.slice(),hi:[i],done:done.slice()});
  }
  return steps;
}
function insertionSteps(arr){
  var a=arr.slice(),n=a.length,steps=[];
  steps.push({arr:a.slice(),hi:[],done:[]});
  for(var i=1;i<n;i++){
    var key=a[i],j=i-1;
    while(j>=0&&a[j]>key){a[j+1]=a[j];steps.push({arr:a.slice(),hi:[j,j+1],done:[]});j--;}
    a[j+1]=key;
    steps.push({arr:a.slice(),hi:[j+1],done:[]});
  }
  return steps;
}

function startViz(){
  var raw=document.getElementById('viz-in').value;
  var arr=raw.split(',').map(function(x){return parseInt(x.trim());}).filter(function(x){return !isNaN(x);}).slice(0,20);
  if(!arr.length)return;
  var algo=document.getElementById('viz-algo').value;
  if(algo==='bubble') _vsteps=bubbleSteps(arr);
  else if(algo==='selection') _vsteps=selectionSteps(arr);
  else _vsteps=insertionSteps(arr);
  _vstep=0;
  drawViz();
}

function randViz(){
  var a=[];for(var i=0;i<12;i++)a.push(Math.floor(Math.random()*99)+1);
  document.getElementById('viz-in').value=a.join(',');
  startViz();
}

function drawViz(){
  if(!_vsteps.length)return;
  var s=_vsteps[_vstep],mx=Math.max.apply(null,s.arr);
  var bars='';
  for(var k=0;k<s.arr.length;k++){
    var h=Math.max(6,(s.arr[k]/mx*100)).toFixed(0);
    var color=s.done.indexOf(k)>=0?'#9ece6a':s.hi.indexOf(k)>=0?'#e0af68':'#7aa2f7';
    bars+='<div class="vbar" style="height:'+h+'px;background:'+color+'"><span>'+s.arr[k]+'</span></div>';
  }
  document.getElementById('viz-out').innerHTML=
    '<div class="viz-bars">'+bars+'</div>'+
    '<div style="display:flex;gap:8px;align-items:center">'+
    '<button class="btn btn-ghost" onclick="stepViz(-1)">◀ Назад</button>'+
    '<span style="color:#495670;font-size:12px">Крок '+(_vstep+1)+' / '+_vsteps.length+'</span>'+
    '<button class="btn btn-ghost" onclick="stepViz(1)">Вперед ▶</button>'+
    '<span style="font-size:11px;color:#495670;margin-left:8px">🟡 swap &nbsp; 🟢 відсортовано &nbsp; 🔵 звичайний</span>'+
    '</div>';
}

function stepViz(d){
  _vstep=Math.max(0,Math.min(_vsteps.length-1,_vstep+d));
  drawViz();
}

// ПОРІВНЯННЯ
function randCmp(){
  var a=[];for(var i=0;i<15;i++)a.push(Math.floor(Math.random()*999)+1);
  document.getElementById('cmp-in').value=a.join(',');
}

function doCompare(){
  var raw=document.getElementById('cmp-in').value;
  var arr=raw.split(',').map(function(x){return parseInt(x.trim());}).filter(function(x){return !isNaN(x);});
  if(!arr.length)return;

  var results=[];
  for(var i=0;i<ALGOS.length;i++){
    var t1=performance.now(), r=ALGOS[i].fn(arr), t2=performance.now();
    results.push({name:ALGOS[i].name,color:ALGOS[i].color,ms:(t2-t1).toFixed(3),cmp:r.cmp,swp:r.swp,sorted:r.sorted});
  }
  var fastest=results.reduce(function(a,b){return parseFloat(a.ms)<parseFloat(b.ms)?a:b;});

  var html='<p style="color:#495670;font-size:12px;margin-bottom:12px">Вхідний масив ('+arr.length+' ел.): ['+arr.join(', ')+']</p>'+
    '<table><thead><tr><th>Алгоритм</th><th>Час (мс)</th><th>Порівнянь</th><th>Обмінів</th><th>Результат (перші 8)</th></tr></thead><tbody>';
  for(var i=0;i<results.length;i++){
    var r=results[i];
    var cls=parseFloat(r.ms)===parseFloat(fastest.ms)?'t-fast':parseFloat(r.ms)<5?'t-mid':'t-slow';
    html+='<tr>'+
      '<td style="color:'+r.color+';font-weight:700">'+r.name+(r.name===fastest.name?' ⚡':'')+'</td>'+
      '<td class="'+cls+'">'+r.ms+' мс</td>'+
      '<td>'+r.cmp.toLocaleString()+'</td>'+
      '<td>'+r.swp.toLocaleString()+'</td>'+
      '<td style="color:#495670;font-size:11px">['+r.sorted.slice(0,8).join(', ')+(r.sorted.length>8?', ...':'')+']</td>'+
    '</tr>';
  }
  html+='</tbody></table><p style="color:#495670;font-size:12px;margin-top:10px">⚡ Найшвидший: <strong style="color:'+fastest.color+'">'+fastest.name+'</strong> — '+fastest.ms+' мс</p>';
  document.getElementById('cmp-out').innerHTML=html;
}
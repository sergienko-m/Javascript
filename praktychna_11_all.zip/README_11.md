# js-oop-variant1

**Практична робота 11 — Варіант 1**  
Система управління транспортом · Класи та ООП

## Структура класів

```
Vehicle (базовий)
├── Car extends Vehicle
├── Truck extends Vehicle
└── Motorcycle extends Vehicle
Fleet (менеджер автопарку)
```

## Реалізація

### Базовий клас Vehicle
```js
class Vehicle {
  #mileage   = 0;    // приватне поле
  #fuelLevel = 100;  // приватне поле

  constructor(brand, model, year) { ... }
  get mileage()   { return this.#mileage; }   // getter
  get fuelLevel() { return this.#fuelLevel; } // getter
  drive(distance) { ... }   // зменшує паливо, збільшує пробіг
  refuel(amount)  { ... }   // заправка
  getMaintenance(){ ... }   // вартість обслуговування
  static compareByMileage(a, b) { ... } // статичний метод
}
```

### Наслідування
```js
class Car extends Vehicle {
  constructor(...args, doors, transmission) {
    super(...args); // виклик Vehicle constructor
    this.doors = doors;
  }
  getMaintenance() { return super.getMaintenance() * 0.9; } // поліморфізм
}
```

### Принципи ООП
- **Інкапсуляція** — приватні поля `#mileage`, `#fuelLevel`
- **Наслідування** — `extends` + `super`
- **Поліморфізм** — `getMaintenance()` різний для кожного типу
- **Абстракція** — `Fleet` приховує деталі управління

## Запуск

Відкрити `praktychna_11_variant1.html` у браузері.

## Demo відео

> 🎥 https://youtu.be/gJjQrktbZo8?si=78hiqf_9XEN77ncT

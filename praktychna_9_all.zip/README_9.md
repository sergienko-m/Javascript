# js-closures-variant1 / part1 / part2

**Практична робота 9 — Варіант 1**  
Замикання · Паттерни · Просунуті техніки

---

## Практична 9 — Counter Factory + Мемоізація

### Counter Factory
```js
createCounter(initial)           // increment, decrement, get, reset
createLimitedCounter(min, max)   // не виходить за межі
createStepCounter(step)          // зі змінним кроком
createNamedCounter(name)         // з приватною історією змін
```

### Мемоізація
```js
memoize(fn)                  // кеш у замиканні, hits/misses
memoizeExpiring(fn, ttlMs)   // з часом життя
```

---

## Практична 9.1 — Паттерни замикань

- **Приватні змінні** — недоступні ззовні
- **Module Pattern** — IIFE + публічний API
- **IIFE** — Immediately Invoked Function Expression
- **Незалежні екземпляри** — кожен зі своїм замиканням

---

## Практична 9.2 — Memoization Library

```js
memoize(fn)                    // базова мемоізація + статистика
memoizeWith(fn, keyFn)         // кастомна функція ключа
memoizeExpiring(fn, ttlMs)     // TTL кеш
createLRUCache(maxSize)        // LRU з витісненням
```

### Benchmark (fib(35))
| Підхід | Час | Виклики |
|---|---|---|
| Без мемоізації | ~200 мс | ~29M |
| З мемоізацією | ~0.1 мс | 36 |

---

## Запуск

Відкрити відповідний HTML файл у браузері.

## Demo відео

| Робота | Посилання |
|---|---|
| Практична 9   | 🎥 https://youtu.be/MJisGq6xV7Q?si=eJY-xGTLuPpFRqqq |
| Практична 9.1 | 🎥 https://youtu.be/KTmjyN2wK3Y?si=DF6TYgd0xU4QUEj8 |
| Практична 9.2 | 🎥 https://youtu.be/D5FSuMM0lI4?si=ixw62zqundz-rN5p |

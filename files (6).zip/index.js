// ============================================================
// Самостійна робота №1. Змінні та типи даних
// ============================================================

// -----------------------------------------------------------
// Завдання 1. Створення та ініціалізація змінних
// -----------------------------------------------------------
let name = "Іван";
let age = 20;
let isStudent = true;
let favoriteColor = "синій";

console.log("=== Завдання 1 ===");
console.log("Ім'я:", name);
console.log("Вік:", age);
console.log("Студент:", isStudent);
console.log("Улюблений колір:", favoriteColor);

// -----------------------------------------------------------
// Завдання 2. Операції з змінними
// -----------------------------------------------------------
let num1 = 10;
let num2 = 20;

let sum = num1 + num2;
let difference = num1 - num2;
let product = num1 * num2;
let quotient = num1 / num2;

console.log("\n=== Завдання 2 ===");
console.log("Сума:", sum);           // 30
console.log("Різниця:", difference); // -10
console.log("Добуток:", product);    // 200
console.log("Частка:", quotient);    // 0.5

// -----------------------------------------------------------
// Завдання 3. Конкатенація рядків
// -----------------------------------------------------------
let firstName = "Іван";
let lastName = "Франко";
let fullName = firstName + " " + lastName;

console.log("\n=== Завдання 3 ===");
console.log("Повне ім'я:", fullName); // Іван Франко

// -----------------------------------------------------------
// Завдання 4. Перетворення типів
// -----------------------------------------------------------
let numberAsString = "123";
let number = Number.parseInt(numberAsString); // рядок → число
let stringNumber = String(number);            // число → рядок

console.log("\n=== Завдання 4 ===");
console.log("number:", number, "| тип:", typeof number);             // 123 | number
console.log("stringNumber:", stringNumber, "| тип:", typeof stringNumber); // "123" | string

// -----------------------------------------------------------
// Завдання 5. Логічні операції
// -----------------------------------------------------------
let isSunny = true;
let isRaining = false;

let rainingAndSunny = isRaining && isSunny;  // AND
let rainingOrSunny  = isRaining || isSunny;  // OR

console.log("\n=== Завдання 5 ===");
console.log("Дощ І сонячно (AND):", rainingAndSunny); // false
console.log("Дощ АБО сонячно (OR):", rainingOrSunny); // true

// -----------------------------------------------------------
// Завдання 6. Оператор typeof + практичні перевірки
// -----------------------------------------------------------
let x = 42;
let y = "привіт";
let z = [1, 2, 3];

console.log("\n=== Завдання 6 — typeof ===");
console.log("x =", x, "| typeof:", typeof x); // number
console.log("y =", y, "| typeof:", typeof y); // string
console.log("z =", z, "| typeof:", typeof z); // object  (масив — це object у JS)

// Перевірка повноліття
let userAge = 17;
let isAdult = userAge >= 18;
console.log("\nВік користувача:", userAge);
console.log("Повнолітній:", isAdult); // false

// Перевірка, чи є значення числом
let price = 99.99;
let isPriceNumber = typeof price === "number";
console.log("\nЦіна:", price);
console.log("Є числом:", isPriceNumber); // true

// Перевірка валідності email (базовий регулярний вираз)
let email = "ivan@example.com";
let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
let isEmailValid = emailRegex.test(email);
console.log("\nEmail:", email);
console.log("Валідний email:", isEmailValid); // true

// Перевірка пароля: мінімум 8 символів, є цифра та велика літера
let password = "Secret42";
let isPasswordValid =
  password.length >= 8 &&
  /[0-9]/.test(password) &&
  /[A-Z]/.test(password);
console.log("\nПароль:", password);
console.log("Відповідає вимогам:", isPasswordValid); // true

/**
 * @fileoverview Demo — демонстрація роботи User Management System
 * Запуск: node demo.js
 */

const { createUser, createUserManager, ROLES } = require('./src/user');

const log = (label, value) => {
  console.log(`\n${'─'.repeat(50)}`);
  console.log(`📌 ${label}`);
  console.log('─'.repeat(50));
  if (typeof value === 'object') {
    console.log(JSON.stringify(value, null, 2));
  } else {
    console.log(value);
  }
};

console.log('\n╔══════════════════════════════════════════════════╗');
console.log('║       USER MANAGEMENT SYSTEM — DEMO             ║');
console.log('╚══════════════════════════════════════════════════╝');

// ── 1. Standalone createUser ───────────────────────────────────────────────
const alice = createUser({ name: 'Alice Smith', email: 'alice@example.com', role: ROLES.ADMIN });
log('createUser() — Alice (ADMIN)', alice.getInfo());
log('isAdmin()', alice.isAdmin());

// Деструктуризація
const { name, email, role, id } = alice;
log('Деструктуризація { name, email, role, id }', { name, email, role, id });

// updateProfile — immutable
const aliceUpdated = alice.updateProfile({ name: 'Alice Johnson' });
log('updateProfile() — нове ім\'я (оригінал незмінний)', {
  original: alice.name,
  updated: aliceUpdated.name,
});

// ── 2. UserManager ──────────────────────────────────────────────────────────
const manager = createUserManager();

const users = [
  { name: 'Bob Builder',   email: 'bob@example.com',   role: ROLES.USER },
  { name: 'Carol White',   email: 'carol@example.com', role: ROLES.MODERATOR },
  { name: 'Dave Green',    email: 'dave@example.com',  role: ROLES.USER },
  { name: 'Eve Admin',     email: 'eve@example.com',   role: ROLES.ADMIN },
  { name: 'Frank Guest',   email: 'frank@example.com', role: ROLES.GUEST },
];

const added = users.map((u) => manager.addUser(u));
log('addUser() × 5 — getAllUsers().length', manager.count);

// getUser
const bob = added[0];
log('getUser(id) — Bob', manager.getUser(bob.id).getInfo());

// getUsersByRole
const userRoles = manager.getUsersByRole(ROLES.USER);
log('getUsersByRole(USER)', userRoles.map((u) => u.name));

const admins = manager.getUsersByRole(ROLES.ADMIN);
log('getUsersByRole(ADMIN)', admins.map((u) => u.name));

// updateUser
const updatedBob = manager.updateUser(bob.id, { name: 'Bob Updated', role: ROLES.MODERATOR });
log('updateUser() — Bob після оновлення', updatedBob.getInfo());
log('Оригінальний ID збережено?', updatedBob.id === bob.id);

// Object.keys / Object.values / Object.entries
log(
  'Object.keys(user)',
  Object.keys(added[1]).filter((k) => typeof added[1][k] !== 'function')
);

// Spread — копія з overrides (для демо)
const spreadDemo = { ...added[2], name: 'Carol COPY' };
log('Spread оператор — копія з новим ім\'ям', { original: added[2].name, copy: spreadDemo.name });

// deleteUser
manager.deleteUser(added[4].id);
log('deleteUser(Frank) — count після видалення', manager.count);

// getStats
log('getStats()', manager.getStats());

// ── 3. Валідація та error handling ──────────────────────────────────────────
console.log('\n' + '─'.repeat(50));
console.log('🚨 Валідація та error handling:');

const errorCases = [
  { label: 'Некоректний email',   fn: () => manager.addUser({ name: 'Test', email: 'notanemail' }) },
  { label: 'Коротке ім\'я',       fn: () => manager.addUser({ name: 'A',    email: 'a@b.com' }) },
  { label: 'Дублікат email',      fn: () => manager.addUser({ name: 'Dupe', email: 'bob@example.com' }) },
  { label: 'Невалідна роль',      fn: () => manager.addUser({ name: 'Test', email: 'r@r.com', role: 'superuser' }) },
  { label: 'getUser — no ID',     fn: () => manager.getUser('fake-id') },
  { label: 'Мутація frozen obj',  fn: () => { alice.name = 'Hacked'; } },
];

errorCases.forEach(({ label, fn }) => {
  try {
    fn();
  } catch (e) {
    console.log(`  ✅ ${label}: "${e.message}"`);
  }
});

console.log('\n✅ Demo завершено!\n');

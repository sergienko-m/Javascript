/**
 * @fileoverview Unit тести для User Management System
 */

const { createUser, createUserManager, ROLES, isValidEmail } = require('../src/user');

// ─────────────────────────────────────────────────────────────────────────────
// isValidEmail
// ─────────────────────────────────────────────────────────────────────────────
describe('isValidEmail', () => {
  test('приймає коректний email', () => {
    expect(isValidEmail('user@example.com')).toBe(true);
    expect(isValidEmail('test.name+tag@domain.org')).toBe(true);
  });

  test('відхиляє некоректний email', () => {
    expect(isValidEmail('notanemail')).toBe(false);
    expect(isValidEmail('@nodomain.com')).toBe(false);
    expect(isValidEmail('missing@')).toBe(false);
    expect(isValidEmail('')).toBe(false);
    expect(isValidEmail(null)).toBe(false);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// createUser
// ─────────────────────────────────────────────────────────────────────────────
describe('createUser', () => {
  test('створює користувача з коректними даними', () => {
    const user = createUser({ name: 'Іван Петров', email: 'ivan@test.com' });
    expect(user.name).toBe('Іван Петров');
    expect(user.email).toBe('ivan@test.com');
    expect(user.role).toBe(ROLES.USER);
    expect(user.id).toMatch(/^[0-9a-f-]{36}$/);
    expect(user.createdAt).toBeInstanceOf(Date);
  });

  test('нормалізує email до нижнього регістру', () => {
    const user = createUser({ name: 'Тест', email: 'TEST@MAIL.COM' });
    expect(user.email).toBe('test@mail.com');
  });

  test('обрізає пробіли в імені та email', () => {
    const user = createUser({ name: '  Олег  ', email: '  oleh@mail.com  ' });
    expect(user.name).toBe('Олег');
    expect(user.email).toBe('oleh@mail.com');
  });

  test('встановлює роль admin', () => {
    const user = createUser({ name: 'Admin', email: 'admin@site.com', role: ROLES.ADMIN });
    expect(user.role).toBe(ROLES.ADMIN);
    expect(user.isAdmin()).toBe(true);
  });

  test('кидає помилку при некоректному email', () => {
    expect(() => createUser({ name: 'Test', email: 'bad-email' })).toThrow(/email/i);
  });

  test('кидає помилку при короткому імені', () => {
    expect(() => createUser({ name: 'A', email: 'a@b.com' })).toThrow(/ім'я/i);
  });

  test('кидає помилку при невалідній ролі', () => {
    expect(() => createUser({ name: 'Test', email: 'test@a.com', role: 'superuser' })).toThrow(/роль/i);
  });

  test('об\'єкт є immutable (заморожений)', () => {
    const user = createUser({ name: 'Frozen', email: 'frozen@test.com' });
    expect(Object.isFrozen(user)).toBe(true);
    // В strict mode кидає TypeError; в sloppy mode — мовчки ігнорує
    try { user.name = 'Hacked'; } catch (_) { /* ok */ }
    expect(user.name).toBe('Frozen');
  });

  test('кожен користувач має унікальний ID', () => {
    const ids = new Set(
      Array.from({ length: 100 }, () =>
        createUser({ name: 'Test User', email: `u${Math.random()}@test.com` }).id
      )
    );
    expect(ids.size).toBe(100);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// User methods
// ─────────────────────────────────────────────────────────────────────────────
describe('User методи', () => {
  let user;

  beforeEach(() => {
    user = createUser({ name: 'Марія Коваль', email: 'maria@test.com', role: ROLES.MODERATOR });
  });

  test('getInfo() повертає форматований рядок', () => {
    const info = user.getInfo();
    expect(info).toContain('Марія Коваль');
    expect(info).toContain('maria@test.com');
    expect(info).toContain('MODERATOR');
    expect(info).toContain(user.id);
  });

  test('isAdmin() повертає false для moderator', () => {
    expect(user.isAdmin()).toBe(false);
  });

  test('isAdmin() повертає true для admin', () => {
    const admin = createUser({ name: 'Admin User', email: 'admin@test.com', role: ROLES.ADMIN });
    expect(admin.isAdmin()).toBe(true);
  });

  test('updateProfile() повертає новий об\'єкт, не мутує оригінал', () => {
    const updated = user.updateProfile({ name: 'Марія Іваненко' });
    expect(updated.name).toBe('Марія Іваненко');
    expect(user.name).toBe('Марія Коваль'); // оригінал незмінний
  });

  test('updateProfile() зберігає незмінені поля', () => {
    const updated = user.updateProfile({ role: ROLES.ADMIN });
    expect(updated.email).toBe(user.email);
    expect(updated.role).toBe(ROLES.ADMIN);
  });

  test('updateProfile() ігнорує недозволені поля', () => {
    const updated = user.updateProfile({ id: 'fake-id', createdAt: new Date(0), name: 'Valid' });
    expect(updated.name).toBe('Valid');
    expect(updated.id).not.toBe('fake-id');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// createUserManager
// ─────────────────────────────────────────────────────────────────────────────
describe('UserManager', () => {
  let manager;

  beforeEach(() => {
    manager = createUserManager();
  });

  // addUser
  describe('addUser()', () => {
    test('додає користувача та повертає його', () => {
      const user = manager.addUser({ name: 'Олена', email: 'olena@test.com' });
      expect(user.name).toBe('Олена');
      expect(manager.count).toBe(1);
    });

    test('кидає помилку при дублікаті email', () => {
      manager.addUser({ name: 'Перший', email: 'same@test.com' });
      expect(() => manager.addUser({ name: 'Другий', email: 'same@test.com' })).toThrow(/email/i);
    });

    test('кидає помилку при некоректних даних', () => {
      expect(() => manager.addUser({ name: 'X', email: 'bad' })).toThrow();
    });
  });

  // getUser
  describe('getUser()', () => {
    test('повертає користувача за ID', () => {
      const user = manager.addUser({ name: 'Тест', email: 'get@test.com' });
      expect(manager.getUser(user.id)).toEqual(user);
    });

    test('кидає помилку при відсутньому ID', () => {
      expect(() => manager.getUser('non-existent-id')).toThrow(/не знайдено/i);
    });
  });

  // updateUser
  describe('updateUser()', () => {
    test('оновлює ім\'я користувача', () => {
      const user = manager.addUser({ name: 'Стара', email: 'update@test.com' });
      const updated = manager.updateUser(user.id, { name: 'Нова' });
      expect(updated.name).toBe('Нова');
      expect(updated.email).toBe('update@test.com');
    });

    test('зберігає оригінальний ID після оновлення', () => {
      const user = manager.addUser({ name: 'ID Test', email: 'id@test.com' });
      const updated = manager.updateUser(user.id, { name: 'Updated' });
      expect(updated.id).toBe(user.id);
    });

    test('зберігає оригінальний createdAt після оновлення', () => {
      const user = manager.addUser({ name: 'Date Test', email: 'date@test.com' });
      const updated = manager.updateUser(user.id, { name: 'Changed' });
      expect(updated.createdAt).toEqual(user.createdAt);
    });

    test('кидає помилку при дублікаті email під час оновлення', () => {
      manager.addUser({ name: 'Перший', email: 'first@test.com' });
      const second = manager.addUser({ name: 'Другий', email: 'second@test.com' });
      expect(() => manager.updateUser(second.id, { email: 'first@test.com' })).toThrow(/email/i);
    });

    test('кидає помилку при відсутньому ID', () => {
      expect(() => manager.updateUser('fake', { name: 'X' })).toThrow();
    });
  });

  // deleteUser
  describe('deleteUser()', () => {
    test('видаляє користувача', () => {
      const user = manager.addUser({ name: 'Delete Me', email: 'del@test.com' });
      expect(manager.deleteUser(user.id)).toBe(true);
      expect(manager.count).toBe(0);
    });

    test('кидає помилку при спробі видалити неіснуючого', () => {
      expect(() => manager.deleteUser('no-such-id')).toThrow();
    });
  });

  // getAllUsers
  describe('getAllUsers()', () => {
    test('повертає всіх користувачів', () => {
      manager.addUser({ name: 'Alice', email: 'alice@test.com' });
      manager.addUser({ name: 'Bob', email: 'bob@test.com' });
      expect(manager.getAllUsers()).toHaveLength(2);
    });

    test('повертає порожній масив якщо немає користувачів', () => {
      expect(manager.getAllUsers()).toEqual([]);
    });
  });

  // getUsersByRole
  describe('getUsersByRole()', () => {
    beforeEach(() => {
      manager.addUser({ name: 'Admin1', email: 'a1@test.com', role: ROLES.ADMIN });
      manager.addUser({ name: 'Admin2', email: 'a2@test.com', role: ROLES.ADMIN });
      manager.addUser({ name: 'User1', email: 'u1@test.com', role: ROLES.USER });
    });

    test('фільтрує за роллю admin', () => {
      const admins = manager.getUsersByRole(ROLES.ADMIN);
      expect(admins).toHaveLength(2);
      admins.forEach((u) => expect(u.role).toBe(ROLES.ADMIN));
    });

    test('фільтрує за роллю user', () => {
      const users = manager.getUsersByRole(ROLES.USER);
      expect(users).toHaveLength(1);
    });

    test('повертає порожній масив для відсутньої ролі', () => {
      expect(manager.getUsersByRole(ROLES.GUEST)).toEqual([]);
    });
  });

  // getStats
  describe('getStats()', () => {
    test('повертає коректну статистику', () => {
      manager.addUser({ name: 'U1', email: 'u1@s.com', role: ROLES.USER });
      manager.addUser({ name: 'U2', email: 'u2@s.com', role: ROLES.ADMIN });
      manager.addUser({ name: 'U3', email: 'u3@s.com', role: ROLES.MODERATOR });

      const stats = manager.getStats();
      expect(stats.total).toBe(3);
      expect(stats.byRole[ROLES.USER]).toBe(1);
      expect(stats.byRole[ROLES.ADMIN]).toBe(1);
      expect(stats.byRole[ROLES.MODERATOR]).toBe(1);
      expect(stats.emails).toHaveLength(3);
    });
  });

  // Ізоляція між менеджерами
  test('два менеджери мають незалежні сховища', () => {
    const m1 = createUserManager();
    const m2 = createUserManager();
    m1.addUser({ name: 'Only in M1', email: 'only@m1.com' });
    expect(m2.getAllUsers()).toHaveLength(0);
  });
});

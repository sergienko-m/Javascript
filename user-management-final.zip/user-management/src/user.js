/**
 * @fileoverview User Management System
 * @description Система управління користувачами з валідацією, immutable операціями та closures
 */

/**
 * Валідація email адреси
 * @param {string} email
 * @returns {boolean}
 */
const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return typeof email === 'string' && emailRegex.test(email.trim());
};

/**
 * Генерація унікального UUID v4
 * @returns {string}
 */
const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};

/**
 * Допустимі ролі користувачів
 * @enum {string}
 */
const ROLES = Object.freeze({
  ADMIN: 'admin',
  MODERATOR: 'moderator',
  USER: 'user',
  GUEST: 'guest',
});

/**
 * @typedef {Object} UserData
 * @property {string} id - Унікальний ідентифікатор
 * @property {string} name - Ім'я користувача
 * @property {string} email - Email адреса
 * @property {string} role - Роль користувача
 * @property {Date} createdAt - Дата створення
 */

/**
 * Створює об'єкт користувача
 * @param {Object} data - Дані для створення користувача
 * @param {string} data.name - Ім'я
 * @param {string} data.email - Email
 * @param {string} [data.role='user'] - Роль
 * @returns {UserData} Об'єкт користувача
 * @throws {Error} Якщо дані невалідні
 */
const createUser = ({ name, email, role = ROLES.USER } = {}) => {
  // --- Валідація ---
  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    throw new Error('Ім\'я повинно містити мінімум 2 символи');
  }
  if (!isValidEmail(email)) {
    throw new Error(`Невалідний email: "${email}"`);
  }
  const validRoles = Object.values(ROLES);
  if (!validRoles.includes(role)) {
    throw new Error(`Невалідна роль. Допустимі: ${validRoles.join(', ')}`);
  }

  /** @type {UserData} */
  const user = Object.freeze({
    id: generateUUID(),
    name: name.trim(),
    email: email.trim().toLowerCase(),
    role,
    createdAt: new Date(),

    /**
     * Повертає рядкову інформацію про користувача
     * @returns {string}
     */
    getInfo() {
      return `[${this.role.toUpperCase()}] ${this.name} <${this.email}> (ID: ${this.id})`;
    },

    /**
     * Оновлює профіль — повертає новий immutable об'єкт
     * @param {Partial<UserData>} updates - Поля для оновлення
     * @returns {UserData} Новий об'єкт користувача
     */
    updateProfile(updates = {}) {
      const allowed = ['name', 'email', 'role'];
      const filtered = Object.fromEntries(
        Object.entries(updates).filter(([key]) => allowed.includes(key))
      );
      return createUser({ name: this.name, email: this.email, role: this.role, ...filtered });
    },

    /**
     * Перевіряє, чи є користувач адміністратором
     * @returns {boolean}
     */
    isAdmin() {
      return this.role === ROLES.ADMIN;
    },
  });

  return user;
};

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Фабрика UserManager — зберігає приватне сховище через closure
 * @returns {Object} Інтерфейс менеджера користувачів
 */
const createUserManager = () => {
  // Приватне сховище (closure)
  const _store = new Map();

  // ── Внутрішній хелпер ──────────────────────────────────────────────────────
  const _requireUser = (id) => {
    const user = _store.get(id);
    if (!user) throw new Error(`Користувача з ID "${id}" не знайдено`);
    return user;
  };

  // ── Публічний інтерфейс ────────────────────────────────────────────────────
  return {
    /**
     * Створює нового користувача та зберігає у сховищі
     * @param {Object} data
     * @returns {UserData}
     */
    addUser(data) {
      // Перевірка унікальності email
      const emailExists = [..._store.values()].some(
        (u) => u.email === data.email?.trim().toLowerCase()
      );
      if (emailExists) throw new Error(`Email "${data.email}" вже використовується`);

      const user = createUser(data);
      _store.set(user.id, user);
      return user;
    },

    /**
     * Отримує користувача за ID
     * @param {string} id
     * @returns {UserData}
     */
    getUser(id) {
      return _requireUser(id);
    },

    /**
     * Оновлює профіль користувача
     * @param {string} id
     * @param {Object} updates
     * @returns {UserData} Оновлений користувач
     */
    updateUser(id, updates = {}) {
      const existing = _requireUser(id);

      // Якщо оновлюється email — перевірити унікальність
      if (updates.email) {
        const newEmail = updates.email.trim().toLowerCase();
        const duplicate = [..._store.values()].some(
          (u) => u.id !== id && u.email === newEmail
        );
        if (duplicate) throw new Error(`Email "${updates.email}" вже використовується`);
      }

      const updated = createUser({
        name: updates.name ?? existing.name,
        email: updates.email ?? existing.email,
        role: updates.role ?? existing.role,
      });

      // Зберігаємо з оригінальним id та createdAt через spread на plain object
      const merged = Object.freeze({
        ...updated,
        id: existing.id,
        createdAt: existing.createdAt,
        getInfo: updated.getInfo,
        updateProfile: updated.updateProfile,
        isAdmin: updated.isAdmin,
      });

      _store.set(existing.id, merged);
      return merged;
    },

    /**
     * Видаляє користувача
     * @param {string} id
     * @returns {boolean}
     */
    deleteUser(id) {
      _requireUser(id);
      return _store.delete(id);
    },

    /**
     * Повертає всіх користувачів
     * @returns {UserData[]}
     */
    getAllUsers() {
      return [..._store.values()];
    },

    /**
     * Повертає користувачів за роллю
     * @param {string} role
     * @returns {UserData[]}
     */
    getUsersByRole(role) {
      return [..._store.values()].filter((u) => u.role === role);
    },

    /**
     * Кількість користувачів у сховищі
     * @returns {number}
     */
    get count() {
      return _store.size;
    },

    /**
     * Зведена статистика
     * @returns {Object}
     */
    getStats() {
      const users = [..._store.values()];
      const byRole = Object.values(ROLES).reduce((acc, role) => {
        acc[role] = users.filter((u) => u.role === role).length;
        return acc;
      }, {});

      return {
        total: users.length,
        byRole,
        emails: users.map((u) => u.email),
      };
    },
  };
};

module.exports = { createUser, createUserManager, ROLES, isValidEmail, generateUUID };

# User Management System

Практична робота 5 · Варіант 1 · JavaScript Objects

---

## Структура проєкту

```
user-management/
├── src/
│   └── user.js          # Основна логіка
├── tests/
│   └── user.test.js     # Jest unit-тести (36 тестів)
├── demo.js              # Демонстрація всіх можливостей
├── package.json
└── README.md
```

---

## Структури даних

### `UserData` (об'єкт користувача)

| Поле        | Тип    | Опис                              |
|-------------|--------|-----------------------------------|
| `id`        | string | UUID v4, генерується автоматично  |
| `name`      | string | Ім'я (мін. 2 символи)             |
| `email`     | string | Email (нормалізований, нижній регістр) |
| `role`      | string | `admin` / `moderator` / `user` / `guest` |
| `createdAt` | Date   | Дата створення                    |

**Методи об'єкта:**
- `getInfo()` — рядок `[ROLE] Name <email> (ID: ...)`
- `updateProfile(updates)` — immutable оновлення, повертає **новий** об'єкт
- `isAdmin()` → `boolean`

### `ROLES` (enum)

```js
ROLES.ADMIN      // 'admin'
ROLES.MODERATOR  // 'moderator'
ROLES.USER       // 'user'
ROLES.GUEST      // 'guest'
```

### `UserManager` (менеджер сховища)

Внутрішнє сховище — `Map`, приховане через **closure** (недоступне ззовні).

| Метод                    | Опис                                      |
|--------------------------|-------------------------------------------|
| `addUser(data)`          | Створити і зберегти користувача           |
| `getUser(id)`            | Отримати за ID                            |
| `updateUser(id, data)`   | Оновити (зберігає оригінальний id/createdAt) |
| `deleteUser(id)`         | Видалити                                  |
| `getAllUsers()`           | Масив всіх користувачів                   |
| `getUsersByRole(role)`   | Фільтрація за роллю                       |
| `getStats()`             | `{ total, byRole, emails }`               |
| `count` (getter)         | Кількість записів                         |

---

## Технічні особливості

- **Closures** — `_store` (Map) прихований, доступний тільки через методи менеджера
- **Immutability** — `Object.freeze()` на кожному user; `updateProfile()` та `updateUser()` повертають нові об'єкти
- **Деструктуризація** — параметри функцій, отримання полів
- **Spread оператор** — злиття об'єктів при оновленні
- **Object.keys / .values / .entries** — в `getStats()`, фільтрації
- **Getters** — `manager.count`
- **JSDoc** — документація на всіх функціях та типах
- **Валідація** — email regex, мінімальна довжина імені, допустимі ролі, унікальність email

---

## Запуск

```bash
# Встановити залежності
npm install

# Запустити демо
node demo.js

# Запустити тести
npm test
```

---

## Тести (36 штук)

```
isValidEmail         — 2 тести
createUser           — 9 тестів
User методи          — 6 тестів
UserManager.addUser  — 3 тести
UserManager.getUser  — 2 тести
UserManager.updateUser — 5 тестів
UserManager.deleteUser — 2 тести
UserManager.getAllUsers — 2 тести
UserManager.getUsersByRole — 3 тести
UserManager.getStats — 1 тест
Ізоляція між менеджерами — 1 тест
```

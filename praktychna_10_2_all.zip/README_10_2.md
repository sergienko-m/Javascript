# js-async-api-variant1

**Практична робота 10.2 — Варіант 1**  
GitHub User Explorer · async/await · Fetch API · Promise.all

## Про проект

Застосунок для перегляду профілів GitHub користувачів та їх репозиторіїв.  
Використовує **реальний GitHub API** без реєстрації (60 запитів/годину).

## Реалізовано

### async/await
```js
async function searchUser(username) {
  try {
    const [user, repos] = await Promise.all([
      apiFetch(`https://api.github.com/users/${username}`),
      apiFetch(`https://api.github.com/users/${username}/repos`)
    ]);
    renderProfile(user, repos);
  } catch (error) {
    showError(error.message);
  } finally {
    hideSpinner();
  }
}
```

### Функціональність
- 🔍 Пошук користувача за username
- 👤 Профіль: аватар, ім'я, bio, локація, статистика
- 📦 Репозиторії з сортуванням (stars / forks / updated / name)
- 🔎 Деталі репозиторію: мови, ліцензія, статистика
- ⚡ Паралельне завантаження через Promise.all
- 💾 Кешування відповідей (5 хвилин)
- ⚠️ Rate limit індикатор
- 🔄 Loading spinner та error handling

### API Endpoints
```
GET https://api.github.com/users/{username}
GET https://api.github.com/users/{username}/repos
GET https://api.github.com/repos/{owner}/{repo}
GET https://api.github.com/repos/{owner}/{repo}/languages
```

## Запуск

Відкрити `praktychna_10_2_variant1.html` у браузері.  
Потрібен інтернет для роботи з GitHub API.

## Demo відео

> 🎥 https://youtu.be/uACaZiALKqo?si=67ksB4pt84zMIJfL
